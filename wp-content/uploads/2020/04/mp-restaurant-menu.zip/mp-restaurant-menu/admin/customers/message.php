<div class="wrap">
	<h1><?php _e('Delete customer', 'mp-restaurant-menu'); ?></h1>
	<?php do_action('mprm_customer_message_top', $customer); ?>

	<?php do_action('mprm_customer_message_bottom', $customer); ?>
	<div class="info-wrapper customer-section">
	</div>
</div>