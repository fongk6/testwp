<div class="wrap" id="mprm-add-ons">
	<h1><?php _e('Extensions for Restaurant Menu', 'mp-restaurant-menu'); ?>
	<span><a href="https://motopress.com/products/category/restaurant-menu-addons/?utm_source=restaurant-menu-customer-website-dashboard&utm_medium=textlink-in-dashboard&utm_campaign=restaurant-menu-addons" class="button button-primary" target="_blank"><?php _e('Browse All Extensions', 'mp-restaurant-menu'); ?></a></span></h1>
	<div id="mprm_extensions_container">
		<?php echo $extensions_html; ?>
	</div>
</div>