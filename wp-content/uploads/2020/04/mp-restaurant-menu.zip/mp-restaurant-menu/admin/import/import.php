<h2><?php _e('Import', 'mp-restaurant-menu') ?></h2>
<?php wp_import_upload_form('admin.php?import=mprm-importer&amp;step=2'); ?>