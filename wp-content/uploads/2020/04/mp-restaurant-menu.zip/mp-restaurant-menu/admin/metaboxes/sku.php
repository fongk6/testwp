<label for="sku"><?php echo esc_attr($description) ?>:</label> <br>
<input type="text" name="<?php echo esc_attr($name) ?>" value="<?php echo esc_attr($value) ?>"/>