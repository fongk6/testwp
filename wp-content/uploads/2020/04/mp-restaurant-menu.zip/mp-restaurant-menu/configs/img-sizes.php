<?php
return array(
	'middle' => array(
		'width' => '400',
		'height' => '300',
		'crop' => 1
	),
	'big' => array(
		'width' => '800',
		'height' => '600',
		'crop' => 1
	),
	'thumbnail' => array(
		'width' => '150',
		'height' => '150',
		'crop' => 1
	)
);
