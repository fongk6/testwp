<a href="<?php the_permalink() ?>">
	<?php echo mprm_get_item_image($thumbnail); ?>
</a>