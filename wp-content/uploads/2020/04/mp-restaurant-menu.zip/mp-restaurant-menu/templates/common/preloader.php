<div class="mprm-container-preloader">
	<div class="mprm-floating-circles mprm-floating-circle-wrapper <?php echo $class ?>">
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-1"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-2"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-3"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-4"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-5"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-6"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-7"></div>
		<div class="mprm-floating-circle" id="mprm-floating-circle-rotate-8"></div>
	</div>
</div>