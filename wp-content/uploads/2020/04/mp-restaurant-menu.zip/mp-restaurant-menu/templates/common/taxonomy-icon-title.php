<h2 class="mprm-title">
	<i class="mprm-icon <?php echo mprm_get_category_icon() ?>"></i>
</h2>